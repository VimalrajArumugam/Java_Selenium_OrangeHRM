package com.atmecs.qa.SampleProject.constant;

public class LocatorKeyContainer {
	public static final String LEARN_MORE_LINK = "learnMore_link";
	public static final String CONTACT_US_LINK = "contactUs_link";
	public static final String INPUT_1 = "yourname_input";
	public static final String INPUT_2 = "emailid_input";
	public static final String INPUT_3 = "phonenumber_input";
	public static final String INPUT_4 = "companyname_input";
}
